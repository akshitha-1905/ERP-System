function exit() {
    // Redirect to index.html
    window.location.href = "index.html";
}